/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypack;

import java.io.*; 
import java.net.*; 
import javax.servlet.*; 
import javax.servlet.http.*;

/**
 *
 * @author yash maruti mane
 */
public class NonBlockingServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
     @Override
     protected void service(HttpServletRequest request, HttpServletResponse response) 
 throws ServletException, IOException { 
 response.setContentType("text/html;charset=UTF-8"); 
 try (PrintWriter out = response.getWriter()) { 
 
 out.println("<h1>FileReader</h1>"); 
 String filename="/WEB-INF/booklist.txt"; 
 
 ServletContext c=getServletContext(); 
 InputStream in=c.getResourceAsStream(filename); 
 String 
path="http://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath()+"/ReadingNonBloclingServlet"; 
 URL url=new URL(path); 
 HttpURLConnection conn=(HttpURLConnection)url.openConnection(); 
 conn.setChunkedStreamingMode(2); 
 conn.setDoOutput(true); 
 conn.connect(); 
 if(in!=null) 
 { 
 InputStreamReader inr=new InputStreamReader(in); 
 BufferedReader br = new BufferedReader(inr); 
 String text=""; 
 System.out.println("Reading started...."); 
 BufferedWriter bw=new BufferedWriter(new 
OutputStreamWriter(conn.getOutputStream())); 
 while((text=br.readLine())!=null){ 
 out.print(text+"<br>");
try{ 
 Thread.sleep(1000); 
 out.flush(); 
 } 
 catch(InterruptedException ex){} 
}out.print("reading completed...."); 
 bw.flush(); 
 bw.close(); 
 } 
 } 
 } 
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private void processRequest(HttpServletRequest request, HttpServletResponse response) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
